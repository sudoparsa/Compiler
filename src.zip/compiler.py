# Parsa Hosseini 98109583
# Mahdi Salmani 98105824

from Scanner import get_all_tokens


if __name__ == "__main__":
    get_all_tokens(file_path='input.txt')