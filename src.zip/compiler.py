# Parsa Hosseini 98109583
# Mahdi Salmani 98105824

from Scanner import get_all_tokens
from Parser import parse

if __name__ == "__main__":
    parse(file_path='input.txt')
